var express = require('express');
var fs = require('fs');
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.urlencoded({
    extended: true
}));
//  顶部轮播图
app.get('/slide', function (req, res) {
	console.log(111)
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/slide.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  十点抢券、热销榜单、好物特卖、直播特卖
app.get('/item', function (req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/popular.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  限时热卖
app.get('/limit', function (req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/sale.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  流行单品
app.get('/popular', function (_req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/item.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  分类模块
app.get('/classify', function (_req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/classify.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  分类流行
app.get('/fashion', function (_req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/fashion.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  分类热销
app.get('/sell', function (_req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/sell.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  分类上新
app.get('/update', function (_req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/update.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
//  购物车
app.get('/cart', function (_req, res) {
    res.set('Access-Control-Allow-Origin', '*')
    fs.readFile('./data/cart.json','utf-8',function(err,data){
        if(!err){
            res.send(JSON.parse(data))
        }
    })
})
app.use(express.static('www'))
app.listen(3333, function () {
    console.log('服务器开启中....')
})